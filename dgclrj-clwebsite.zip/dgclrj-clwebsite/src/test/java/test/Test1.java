package test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dgclrj.clwebsite.entity.PatientInfo;
import com.dgclrj.clwebsite.service.PatientInfoService;
import com.dgclrj.clwebsite.service.impl.PatientInfoServiceImpl;

public class Test1 {
	private PatientInfoService patientInfoService;
	@Before
	public void init() {
		String[] conf = { "conf/spring-mybatis.xml", "conf/spring-mvc.xml" };
		ApplicationContext ac = new ClassPathXmlApplicationContext(conf);
		patientInfoService = ac.getBean("patientInfoService", PatientInfoServiceImpl.class);
	}
	@Test
	public void find() {
		try {
			List<PatientInfo> p=patientInfoService.find();
			System.out.println(p);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
