package com.dgclrj.clwebsite.entity;

import java.util.Date;

import com.dgclrj.clwebsite.common.util.excel.Excel;

public class PatientInfo {
    
    private Integer pid;

    @Excel(name = "姓名", width = 20)
    private String name;

    private Date enddate;

    @Excel(name = "身份证号", width = 40)
    private String identity;

    @Excel(name = "联系方式", width = 40)
    private String phone;

    @Excel(name = "地区", width = 20)
    private String address;

    @Excel(name = "转诊机构（县区妇幼）", width = 45)
    private String referralinstitution;
    
    @Excel(name = "接收转诊时间", width = 25, dateFormat = "yyyyMMdd")
    private Date referraldate;

    private String referrallist;

    private Date drawblooddate;

    private String drawbloodcode;

    private Date registerdate;

    @Excel(name = "无创DNA", width = 45)
    private String samplenumber;

    @Excel(name = "羊水穿刺", width = 45)
    private String remarks;
    
    @Excel(name = "孕周", width = 20)
    private String week;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Date getEnddate() {
        return enddate;
    }

    public void setEnddate(Date enddate) {
        this.enddate = enddate;
    }

    public String getIdentity() {
        return identity;
    }

    public void setIdentity(String identity) {
        this.identity = identity == null ? null : identity.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getReferralinstitution() {
        return referralinstitution;
    }

    public void setReferralinstitution(String referralinstitution) {
        this.referralinstitution = referralinstitution == null ? null : referralinstitution.trim();
    }

    public Date getReferraldate() {
        return referraldate;
    }

    public void setReferraldate(Date referraldate) {
        this.referraldate = referraldate;
    }

    public String getReferrallist() {
        return referrallist;
    }

    public void setReferrallist(String referrallist) {
        this.referrallist = referrallist == null ? null : referrallist.trim();
    }

    public Date getDrawblooddate() {
        return drawblooddate;
    }

    public void setDrawblooddate(Date drawblooddate) {
        this.drawblooddate = drawblooddate;
    }

    public String getDrawbloodcode() {
        return drawbloodcode;
    }

    public void setDrawbloodcode(String drawbloodcode) {
        this.drawbloodcode = drawbloodcode == null ? null : drawbloodcode.trim();
    }

    public Date getRegisterdate() {
        return registerdate;
    }

    public void setRegisterdate(Date registerdate) {
        this.registerdate = registerdate;
    }

    public String getSamplenumber() {
        return samplenumber;
    }

    public void setSamplenumber(String samplenumber) {
        this.samplenumber = samplenumber == null ? null : samplenumber.trim();
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getWeek() {
        return week;
    }

    public void setWeek(String week) {
        this.week = week;
    }
}