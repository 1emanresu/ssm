package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.IVFInfo;

public interface IVFInfoMapper {
    int deleteByPrimaryKey(Integer iid);

    int insert(IVFInfo record);

    int insertSelective(IVFInfo record);

    IVFInfo selectByPrimaryKey(Integer iid);

    int updateByPrimaryKeySelective(IVFInfo record);

    int updateByPrimaryKey(IVFInfo record);
}