package com.dgclrj.clwebsite.entity;

public class SalesInfo {
    private Integer sid;

    private Integer pid;

    private String salesman;

    private String salesmanassistant;

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getSalesman() {
        return salesman;
    }

    public void setSalesman(String salesman) {
        this.salesman = salesman == null ? null : salesman.trim();
    }

    public String getSalesmanassistant() {
        return salesmanassistant;
    }

    public void setSalesmanassistant(String salesmanassistant) {
        this.salesmanassistant = salesmanassistant == null ? null : salesmanassistant.trim();
    }
}