package com.dgclrj.clwebsite.entity;

public class TangScreen {
    private Integer tid;

    private Integer pid;

    private String tresult;

    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getTresult() {
        return tresult;
    }

    public void setTresult(String tresult) {
        this.tresult = tresult == null ? null : tresult.trim();
    }
}