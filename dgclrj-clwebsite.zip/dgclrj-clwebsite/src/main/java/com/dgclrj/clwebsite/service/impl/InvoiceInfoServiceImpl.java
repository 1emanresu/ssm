package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.InvoiceInfoService;

@Service("invoiceInfoService")
public class InvoiceInfoServiceImpl implements InvoiceInfoService {

}
