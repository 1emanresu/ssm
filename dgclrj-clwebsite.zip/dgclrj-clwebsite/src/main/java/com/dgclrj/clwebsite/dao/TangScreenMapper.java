package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.TangScreen;

public interface TangScreenMapper {
    int deleteByPrimaryKey(Integer tid);

    int insert(TangScreen record);

    int insertSelective(TangScreen record);

    TangScreen selectByPrimaryKey(Integer tid);

    int updateByPrimaryKeySelective(TangScreen record);

    int updateByPrimaryKey(TangScreen record);
}