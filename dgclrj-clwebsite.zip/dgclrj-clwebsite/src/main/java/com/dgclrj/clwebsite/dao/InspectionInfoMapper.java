package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.InspectionInfo;

public interface InspectionInfoMapper {
    int deleteByPrimaryKey(Integer iid);

    int insert(InspectionInfo record);

    int insertSelective(InspectionInfo record);

    InspectionInfo selectByPrimaryKey(Integer iid);

    int updateByPrimaryKeySelective(InspectionInfo record);

    int updateByPrimaryKey(InspectionInfo record);
}