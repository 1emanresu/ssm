package com.dgclrj.clwebsite.entity;

import java.math.BigDecimal;
import java.util.Date;

public class CostInfo {
    private Integer cid;

    private Integer pid;

    private Integer payPid;

    private String ifpayment;

    private BigDecimal amountcollected;

    private Date amountdate;

    private String payee;

    private String payment;

    private BigDecimal testingcost;

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public Integer getPayPid() {
        return payPid;
    }

    public void setPayPid(Integer payPid) {
        this.payPid = payPid;
    }

    public String getIfpayment() {
        return ifpayment;
    }

    public void setIfpayment(String ifpayment) {
        this.ifpayment = ifpayment == null ? null : ifpayment.trim();
    }

    public BigDecimal getAmountcollected() {
        return amountcollected;
    }

    public void setAmountcollected(BigDecimal amountcollected) {
        this.amountcollected = amountcollected;
    }

    public Date getAmountdate() {
        return amountdate;
    }

    public void setAmountdate(Date amountdate) {
        this.amountdate = amountdate;
    }

    public String getPayee() {
        return payee;
    }

    public void setPayee(String payee) {
        this.payee = payee == null ? null : payee.trim();
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment == null ? null : payment.trim();
    }

    public BigDecimal getTestingcost() {
        return testingcost;
    }

    public void setTestingcost(BigDecimal testingcost) {
        this.testingcost = testingcost;
    }
}