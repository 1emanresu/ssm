package com.dgclrj.clwebsite.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.dao.PatientInfoMapper;
import com.dgclrj.clwebsite.entity.PatientInfo;
import com.dgclrj.clwebsite.service.PatientInfoService;

@Service("patientInfoService")
public class PatientInfoServiceImpl implements PatientInfoService {
	@Resource
	private PatientInfoMapper patientInfoDao;

	@Override
	public int insert(PatientInfo patientInfo) {
		return patientInfoDao.insert(patientInfo);
	}

	@Override
	public List<PatientInfo> find() {
		return patientInfoDao.find();
	}

}
