package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.SampleSend;

public interface SampleSendMapper {
    int deleteByPrimaryKey(Integer sid);

    int insert(SampleSend record);

    int insertSelective(SampleSend record);

    SampleSend selectByPrimaryKey(Integer sid);

    int updateByPrimaryKeySelective(SampleSend record);

    int updateByPrimaryKey(SampleSend record);
}