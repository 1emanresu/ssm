package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.PaymentMethod;

public interface PaymentMethodMapper {
    int deleteByPrimaryKey(Integer pid);

    int insert(PaymentMethod record);

    int insertSelective(PaymentMethod record);

    PaymentMethod selectByPrimaryKey(Integer pid);

    int updateByPrimaryKeySelective(PaymentMethod record);

    int updateByPrimaryKey(PaymentMethod record);
}