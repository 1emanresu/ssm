package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ˢ����ϢController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����3:08:02
 */
@Controller
@RequestMapping("/cardInfo")
public class CardInfoController {

}
