package com.dgclrj.clwebsite.entity;

import com.dgclrj.clwebsite.common.util.excel.Excel;

public class DNA {
    private Integer id;

    private Integer pid;

    @Excel(name = "21三体", width = 20)
    private String trisomy21;

    @Excel(name = "18三体", width = 20)
    private String trisomy18;

    @Excel(name = "神经管畸形", width = 20)
    private String nerviduct;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getTrisomy21() {
        return trisomy21;
    }

    public void setTrisomy21(String trisomy21) {
        this.trisomy21 = trisomy21 == null ? null : trisomy21.trim();
    }

    public String getTrisomy18() {
        return trisomy18;
    }

    public void setTrisomy18(String trisomy18) {
        this.trisomy18 = trisomy18 == null ? null : trisomy18.trim();
    }

    public String getNerviduct() {
        return nerviduct;
    }

    public void setNerviduct(String nerviduct) {
        this.nerviduct = nerviduct == null ? null : nerviduct.trim();
    }
}