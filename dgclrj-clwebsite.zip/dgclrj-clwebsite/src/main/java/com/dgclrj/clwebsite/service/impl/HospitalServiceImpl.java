package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.HospitalService;

@Service("hospitalService")
public class HospitalServiceImpl implements HospitalService {

}
