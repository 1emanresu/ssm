package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.DNAService;

@Service("dNAService")
public class DNAServiceImpl implements DNAService {

}
