package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * IVF��ϢController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����3:09:36
 */
@Controller
@RequestMapping("/IVFInfo")
public class IVFInfoController {

}
