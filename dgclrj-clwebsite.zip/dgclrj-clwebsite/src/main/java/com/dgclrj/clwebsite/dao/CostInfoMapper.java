package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.CostInfo;

public interface CostInfoMapper {
    int deleteByPrimaryKey(Integer cid);

    int insert(CostInfo record);

    int insertSelective(CostInfo record);

    CostInfo selectByPrimaryKey(Integer cid);

    int updateByPrimaryKeySelective(CostInfo record);

    int updateByPrimaryKey(CostInfo record);
}