package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.CardInfo;

public interface CardInfoMapper {
    int deleteByPrimaryKey(Integer sid);

    int insert(CardInfo record);

    int insertSelective(CardInfo record);

    CardInfo selectByPrimaryKey(Integer sid);

    int updateByPrimaryKeySelective(CardInfo record);

    int updateByPrimaryKey(CardInfo record);
}