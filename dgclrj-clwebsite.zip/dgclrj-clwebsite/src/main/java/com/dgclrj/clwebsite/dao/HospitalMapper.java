package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.Hospital;

public interface HospitalMapper {
    int deleteByPrimaryKey(Integer hid);

    int insert(Hospital record);

    int insertSelective(Hospital record);

    Hospital selectByPrimaryKey(Integer hid);

    int updateByPrimaryKeySelective(Hospital record);

    int updateByPrimaryKey(Hospital record);
}