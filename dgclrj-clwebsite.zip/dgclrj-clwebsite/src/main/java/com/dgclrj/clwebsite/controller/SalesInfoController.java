package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ������ϢController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����3:10:26
 */
@Controller
@RequestMapping("/salesInfo")
public class SalesInfoController {

}
