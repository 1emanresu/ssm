package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ������ϢController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����3:08:15
 */
@Controller
@RequestMapping("/costInfo")
public class CostInfoController {

}
