package com.dgclrj.clwebsite.dao;

import org.apache.ibatis.annotations.Param;

import com.dgclrj.clwebsite.entity.UserTb;

public interface UserTbMapper {

	/**
	 * �û���¼
	 * 
	 * @param account
	 * @param password
	 * @return UserTb
	 * @author zhangqt
	 * @createDate 2017��12��6�� ����2:07:34
	 */
	UserTb login(@Param("userName") String userName, @Param("password") String password);
}