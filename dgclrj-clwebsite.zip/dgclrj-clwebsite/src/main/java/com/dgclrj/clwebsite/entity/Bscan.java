package com.dgclrj.clwebsite.entity;

public class Bscan {
    private Integer bid;

    private Integer pid;

    private String normaldouble;

    private String normalsingle;

    private String abnormal;

    private String abnormalremarks;

    public Integer getBid() {
        return bid;
    }

    public void setBid(Integer bid) {
        this.bid = bid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getNormaldouble() {
        return normaldouble;
    }

    public void setNormaldouble(String normaldouble) {
        this.normaldouble = normaldouble == null ? null : normaldouble.trim();
    }

    public String getNormalsingle() {
        return normalsingle;
    }

    public void setNormalsingle(String normalsingle) {
        this.normalsingle = normalsingle == null ? null : normalsingle.trim();
    }

    public String getAbnormal() {
        return abnormal;
    }

    public void setAbnormal(String abnormal) {
        this.abnormal = abnormal == null ? null : abnormal.trim();
    }

    public String getAbnormalremarks() {
        return abnormalremarks;
    }

    public void setAbnormalremarks(String abnormalremarks) {
        this.abnormalremarks = abnormalremarks == null ? null : abnormalremarks.trim();
    }
}