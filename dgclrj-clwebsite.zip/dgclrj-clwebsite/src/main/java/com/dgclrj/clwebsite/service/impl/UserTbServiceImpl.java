package com.dgclrj.clwebsite.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.dao.UserTbMapper;
import com.dgclrj.clwebsite.entity.UserTb;
import com.dgclrj.clwebsite.service.UserTbService;

@Service("userTbService")
public class UserTbServiceImpl implements UserTbService {
	@Resource
	private UserTbMapper userTbDao;
	@Override
	public UserTb login(String userName, String password) {
		UserTb UserTb = null;
		try {
			System.out.println(userName);
			System.out.println(password);
			UserTb=userTbDao.login(userName,password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return UserTb;
	}
}
