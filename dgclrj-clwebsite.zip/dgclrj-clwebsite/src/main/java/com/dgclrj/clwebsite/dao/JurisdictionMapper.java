package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.Jurisdiction;

public interface JurisdictionMapper {
    int deleteByPrimaryKey(Integer jid);

    int insert(Jurisdiction record);

    int insertSelective(Jurisdiction record);

    Jurisdiction selectByPrimaryKey(Integer jid);

    int updateByPrimaryKeySelective(Jurisdiction record);

    int updateByPrimaryKey(Jurisdiction record);
}