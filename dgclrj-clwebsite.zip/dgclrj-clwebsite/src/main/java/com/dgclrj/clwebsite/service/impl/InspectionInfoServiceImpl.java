package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.InspectionInfoService;

@Service("inspectionInfoService")
public class InspectionInfoServiceImpl implements InspectionInfoService {

}
