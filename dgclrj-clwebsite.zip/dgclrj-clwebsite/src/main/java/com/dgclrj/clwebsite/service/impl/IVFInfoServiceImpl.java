package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.IVFInfoService;

@Service("iVFInfoService")
public class IVFInfoServiceImpl implements IVFInfoService {

}
