package com.dgclrj.clwebsite.entity;

import java.util.Date;

public class InspectionInfo {
    private Integer iid;

    private String inspectiondoct;

    private Date inspectiondate;

    private String inspectioncompany;

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getInspectiondoct() {
        return inspectiondoct;
    }

    public void setInspectiondoct(String inspectiondoct) {
        this.inspectiondoct = inspectiondoct == null ? null : inspectiondoct.trim();
    }

    public Date getInspectiondate() {
        return inspectiondate;
    }

    public void setInspectiondate(Date inspectiondate) {
        this.inspectiondate = inspectiondate;
    }

    public String getInspectioncompany() {
        return inspectioncompany;
    }

    public void setInspectioncompany(String inspectioncompany) {
        this.inspectioncompany = inspectioncompany == null ? null : inspectioncompany.trim();
    }
}