package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ��Ʊ��ϢController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����3:09:21
 */
@Controller
@RequestMapping("/invoiceInfo")
public class InvoiceInfoController {

}
