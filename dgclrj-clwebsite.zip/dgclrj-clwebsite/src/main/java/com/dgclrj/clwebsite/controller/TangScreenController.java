package com.dgclrj.clwebsite.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * ��ɸController
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����2:53:10
 */
@Controller
@RequestMapping("/tangScreen")
public class TangScreenController {

}
