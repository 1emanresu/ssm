package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.CostInfoService;

@Service("costInfoService")
public class CostInfoServiceImpl implements CostInfoService {

}
