package com.dgclrj.clwebsite.entity;

public class InvoiceInfo {
    private Integer iid;

    private Integer pid;

    private String ifinvoice;

    private String claim;

    private String invoicepeople;

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getIfinvoice() {
        return ifinvoice;
    }

    public void setIfinvoice(String ifinvoice) {
        this.ifinvoice = ifinvoice == null ? null : ifinvoice.trim();
    }

    public String getClaim() {
        return claim;
    }

    public void setClaim(String claim) {
        this.claim = claim == null ? null : claim.trim();
    }

    public String getInvoicepeople() {
        return invoicepeople;
    }

    public void setInvoicepeople(String invoicepeople) {
        this.invoicepeople = invoicepeople == null ? null : invoicepeople.trim();
    }
}