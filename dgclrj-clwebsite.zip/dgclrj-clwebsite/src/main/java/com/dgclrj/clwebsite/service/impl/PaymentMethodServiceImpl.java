package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.PaymentMethodService;

@Service("paymentMethodService")
public class PaymentMethodServiceImpl implements PaymentMethodService {

}
