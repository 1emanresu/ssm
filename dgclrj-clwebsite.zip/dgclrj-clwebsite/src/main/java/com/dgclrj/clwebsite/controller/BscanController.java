package com.dgclrj.clwebsite.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dgclrj.clwebsite.service.BscanService;

/**
 * B��Controller
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����2:51:03
 */
@Controller
@RequestMapping("/bscan")
public class BscanController {
	@Resource
	private BscanService bscanService;
}
