package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.InvoiceInfo;

public interface InvoiceInfoMapper {
    int deleteByPrimaryKey(Integer iid);

    int insert(InvoiceInfo record);

    int insertSelective(InvoiceInfo record);

    InvoiceInfo selectByPrimaryKey(Integer iid);

    int updateByPrimaryKeySelective(InvoiceInfo record);

    int updateByPrimaryKey(InvoiceInfo record);
}