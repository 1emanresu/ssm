package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.SampleSendService;

@Service("sampleSendService")
public class SampleSendServiceImpl implements SampleSendService {

}
