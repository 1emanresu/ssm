package com.dgclrj.clwebsite.service.impl;

import org.springframework.stereotype.Service;

import com.dgclrj.clwebsite.service.SalesInfoService;

@Service("salesInfoService")
public class SalesInfoServiceImpl implements SalesInfoService{

}
