package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.Bscan;

public interface BscanMapper {
    int deleteByPrimaryKey(Integer bid);

    int insert(Bscan record);

    int insertSelective(Bscan record);

    Bscan selectByPrimaryKey(Integer bid);

    int updateByPrimaryKeySelective(Bscan record);

    int updateByPrimaryKey(Bscan record);
}