package com.dgclrj.clwebsite.entity;

import java.util.Date;

public class IVFInfo {
    private Integer iid;

    private Integer pid;

    private String ifivf;

    private Date transplantdate;

    private Integer implantationnum;

    private Integer bednum;

    private Date confirmdate;

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getIfivf() {
        return ifivf;
    }

    public void setIfivf(String ifivf) {
        this.ifivf = ifivf == null ? null : ifivf.trim();
    }

    public Date getTransplantdate() {
        return transplantdate;
    }

    public void setTransplantdate(Date transplantdate) {
        this.transplantdate = transplantdate;
    }

    public Integer getImplantationnum() {
        return implantationnum;
    }

    public void setImplantationnum(Integer implantationnum) {
        this.implantationnum = implantationnum;
    }

    public Integer getBednum() {
        return bednum;
    }

    public void setBednum(Integer bednum) {
        this.bednum = bednum;
    }

    public Date getConfirmdate() {
        return confirmdate;
    }

    public void setConfirmdate(Date confirmdate) {
        this.confirmdate = confirmdate;
    }
}