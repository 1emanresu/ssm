package com.dgclrj.clwebsite.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dgclrj.clwebsite.entity.UserTb;
import com.dgclrj.clwebsite.service.UserTbService;

import com.dgclrj.clwebsite.util.JsonResult;

/**
 * �û���Controller
 * 
 * @author zhangqt
 * @CreateDate 2017��12��6�� ����2:02:16
 */
@Controller
@RequestMapping("/user")
public class UserTbController {
	@Resource
	private UserTbService userTbService;

	/**
	 * �û���¼- ���õ�ַ��HuaDa/user/login.do
	 * 
	 * @param account
	 *            �û��˺�
	 * @param password
	 *            �û�����
	 * @return JsonResult(user����)
	 * @author zhangqt
	 * @createDate 2017��12��06�� ����4:48:50
	 */
	@RequestMapping("/login.do")
	@ResponseBody
	public JsonResult login(String userName, String password) {
		try {
			UserTb userTb = userTbService.login(userName, password);
			System.out.println(userTb);
			Map map = new HashMap();
			map.put("userTb", userTb);
			return new JsonResult(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new JsonResult("");
	}
}
