package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.DNA;

public interface DNAMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(DNA record);

    int insertSelective(DNA record);

    DNA selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(DNA record);

    int updateByPrimaryKey(DNA record);
}