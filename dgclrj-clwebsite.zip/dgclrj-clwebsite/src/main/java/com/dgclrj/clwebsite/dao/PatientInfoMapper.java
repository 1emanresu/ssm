package com.dgclrj.clwebsite.dao;

import java.util.List;

import com.dgclrj.clwebsite.entity.PatientInfo;

public interface PatientInfoMapper {
    int deleteByPrimaryKey(Integer pid);

    int insert(PatientInfo record);

    int insertSelective(PatientInfo record);

    PatientInfo selectByPrimaryKey(Integer pid);

    int updateByPrimaryKeySelective(PatientInfo record);

    int updateByPrimaryKey(PatientInfo record);

	/** 
	 * ��ѯ���л�����Ϣ
	 * @return
	 * @author zhangqt
	 * @createDate 2017��12��6�� ����1:55:01
	 */
	List<PatientInfo> find();
}