package com.dgclrj.clwebsite.entity;

import java.util.Date;

public class SampleSend {
    private Integer sid;

    private Integer pid;

    private String sender;

    private Date senderdate;

    private String couriernumber;

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender == null ? null : sender.trim();
    }

    public Date getSenderdate() {
        return senderdate;
    }

    public void setSenderdate(Date senderdate) {
        this.senderdate = senderdate;
    }

    public String getCouriernumber() {
        return couriernumber;
    }

    public void setCouriernumber(String couriernumber) {
        this.couriernumber = couriernumber == null ? null : couriernumber.trim();
    }
}