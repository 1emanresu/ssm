package com.dgclrj.clwebsite.entity;

import java.math.BigDecimal;

public class CardInfo {
    private Integer sid;

    private Integer pid;

    private BigDecimal money;

    private BigDecimal servicecharge;

    private BigDecimal accounmoney;

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public BigDecimal getServicecharge() {
        return servicecharge;
    }

    public void setServicecharge(BigDecimal servicecharge) {
        this.servicecharge = servicecharge;
    }

    public BigDecimal getAccounmoney() {
        return accounmoney;
    }

    public void setAccounmoney(BigDecimal accounmoney) {
        this.accounmoney = accounmoney;
    }
}