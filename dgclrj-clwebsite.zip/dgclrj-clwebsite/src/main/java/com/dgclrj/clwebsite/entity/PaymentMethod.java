package com.dgclrj.clwebsite.entity;

public class PaymentMethod {
    private Integer pid;

    private String modename;

    public Integer getPid() {
        return pid;
    }

    public void setPid(Integer pid) {
        this.pid = pid;
    }

    public String getModename() {
        return modename;
    }

    public void setModename(String modename) {
        this.modename = modename == null ? null : modename.trim();
    }
}