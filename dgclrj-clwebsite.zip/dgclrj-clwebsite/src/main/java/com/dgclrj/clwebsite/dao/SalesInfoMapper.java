package com.dgclrj.clwebsite.dao;

import com.dgclrj.clwebsite.entity.SalesInfo;

public interface SalesInfoMapper {
    int deleteByPrimaryKey(Integer sid);

    int insert(SalesInfo record);

    int insertSelective(SalesInfo record);

    SalesInfo selectByPrimaryKey(Integer sid);

    int updateByPrimaryKeySelective(SalesInfo record);

    int updateByPrimaryKey(SalesInfo record);
}